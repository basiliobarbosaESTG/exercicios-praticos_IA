def pergunta1(euros_pergunta):  # Pergunta 1
    print("Qual era o cognome do rei português D.Afonso II ?")
    print("a) O conquistador")
    print("b) O venturoso")
    print("c) O Africano")
    print("d) O gordo")

    a = input("Resposta:")

    if (a == 'd'):
        return euros_pergunta
    else:
        return 0


def pergunta2(euros_pergunta):  # Pergunta 2
    print("Como se chama na vida real o conhecido 'Mr.Bean'?")
    print("a) Johnny English")
    print("b) Roger Barclay")
    print("c) Rowan Atkinson")
    print("d) Simon Baker")

    a = input("Resposta:")

    if (a == 'c'):
        return euros_pergunta
    else:
        return 0


def pergunta3(euros_pergunta):  # Pergunta 3
    print("Quem desenhou o elevador de Santa Justa em Lisboa?")
    print("a) Gustavo Eiffel")
    print("b) Menier de Ponsard")
    print("c) Frank Lloyd")
    print("d) Charles Renni Mackintosh")

    a = input("Resposta:")

    if (a == 'b'):
        return euros_pergunta
    else:
        return 0


def pergunta4(euros_pergunta):  # Pergunta 4
    print("Na mitologia, que figura corresponde a Dionísio?")
    print("a) Baco")
    print("b) jupiter")
    print("c) Nereu")
    print("d) Narciso")

    a = input("Resposta:")

    if (a == 'a'):
        return euros_pergunta
    else:
        return 0


def pergunta5(euros_pergunta):  # Pergunta 5
    print("Qual destes paises tem na sua bandeira as mesmas cores que a bandeira francesa?")
    print("a) Belgica")
    print("b) Alemanha")
    print("c) Camarões")
    print("d) Holanda")

    a = input("Resposta:")

    if (a == 'd'):
        return euros_pergunta
    else:
        return 0


def pergunta6(euros_pergunta):  # Pergunta 6
    print("Durante um jogo de Andebol, quantos jogadores tem em campo cada uma das equipas?")
    print("a) 7")
    print("b) 5")
    print("c) 6")
    print("d) 8")

    a = input("Resposta:")

    if (a == 'a'):
        return euros_pergunta
    else:
        return 0


def pergunta7(euros_pergunta):  # Pergunta 7
    print("Onde se situa o vulcão Vesúvio?")
    print("a) Grécia")
    print("b) México")
    print("c) Itália")
    print("d) Venezuela")

    a = input("Resposta:")

    if (a == 'c'):
        return euros_pergunta
    else:
        return 0


def pergunta8(euros_pergunta):  # Pergunta 8
    print("Que século ficou conhecimento por 'Século das Luzes'? ")
    print("a) Século XX")
    print("b) Século XVIII")
    print("c) Século XV")
    print("d) Século XIII")

    a = input("Resposta:")

    if (a == 'b'):
        return euros_pergunta
    else:
        return 0


def pergunta9(euros_pergunta):  # Pergunta 9
    print("Castelo Branco é uma capital de distrito...")
    print("a) Da Beira Baixa")
    print("b) Da Beiro Alta")
    print("c) Do Minho")
    print("d) Do Alto Alentejo")

    a = input("Resposta:")

    if (a == 'a'):
        return euros_pergunta
    else:
        return 0


def pergunta10(euros_pergunta):  # Pergunta 10
    print("Em que museu é possivel ver a 'Mona Lisa' de Leonardo da Vinci?")
    print("a) Prado")
    print("b) Tate Gallery")
    print("c) Louvre")
    print("d) Guibenklan")

    a = input("Resposta:")

    if (a == 'c'):
        return euros_pergunta
    else:
        return 0


def pergunta11(euros_pergunta):  # Pergunta 11
    print("Qual for a canção portuguesa mais bem classificada numa final do Festival da Eurovisão")
    print("a) Bem Bom")
    print("b) Não Sejas Mau para Min")
    print("c) Silêncio e tanta Gente")
    print("d) O Meu Coração Não Tem Cor")

    a = input("Resposta:")

    if (a == 'd'):
        return euros_pergunta
    else:
        return 0


def pergunta12(euros_pergunta):  # Pergunta 12
    print("Que planeta do nosso sistema solar tem a famosa Grande Mancha Vermelha na sua atmosfera")
    print("a) júpiter")
    print("b) Saturno")
    print("c) Urano")
    print("d) Vénus")

    a = input("Resposta:")

    if (a == 'a'):
        return euros_pergunta
    else:
        return 0


def pergunta13(euros_pergunta):  # Pergunta 13
    print("Em que ano foi fundado a Universidade de Aveiro?")
    print("a) 1960")
    print("b) 1970")
    print("c) 1973")
    print("d) 1963")

    a = input("Resposta:")

    if (a == 'c'):
        return euros_pergunta
    else:
        return 0


def pergunta14(euros_pergunta):  # Pergunta 14
    print("Qual é a banda que toca a musica 'Stairway to Heaven'?")
    print("a) Guns n´Roses")
    print("b) Bon jovi")
    print("c) Aerosmith")
    print("d) Led Zeppelin")

    a = input("Resposta:")

    if (a == 'd'):
        return euros_pergunta
    else:
        return 0


def pergunta15(euros_pergunta):  # Pergunta 15
    print("Quantos paises existem no Planeta Terra?")
    print("a) 195")
    print("b) 190")
    print("c) 200")
    print("d) 194")

    a = input("Resposta:")

    if (a == 'a'):
        return euros_pergunta
    else:
        return 0


##################################################################################################################
# Inicio
print("Bem-Vindo ao Quem quer ser milionário")

lista_niveis = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000,
                9000, 10000, 11000, 12000, 13000, 14000, 15000]

print("Níveis dos Prémios")

for index in range(0, len(lista_niveis), 1):
    print("Níveis:", lista_niveis[index], "€")


inicio = input("Deseja iniciar o jogo? (s/n)")

index = 0

while (inicio == "s" or inicio == "S"):

    # Pergunta 1

    resultado = pergunta1(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 0€")
        break
    else:
        print("Ganhou 1000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 2

    resultado = pergunta2(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 0€")
        break
    else:
        print("Ganhou 2000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break
# Pergunta 3

    resultado = pergunta3(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 0€")
        break
    else:
        print("Ganhou 3000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 4
    resultado = pergunta4(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 0€")
        break
    else:
        print("Ganhou 4000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 5
    resultado = pergunta5(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 0€")
        break
    else:
        print("Ganhou 5000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 6
    resultado = pergunta6(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 5000€")
        break
    else:
        print("Ganhou 6000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 7
    resultado = pergunta7(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 5000€")
        break
    else:
        print("Ganhou 7000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 8
    resultado = pergunta8(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 5000€")
        break
    else:
        print("Ganhou 8000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 9
    resultado = pergunta9(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 5000€")
        break
    else:
        print("Ganhou 9000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 10
    resultado = pergunta10(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 5000€")
        break
    else:
        print("Ganhou 10000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 11
    resultado = pergunta11(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 10000€")
        break
    else:
        print("Ganhou 11000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break


# Pergunta 12
    resultado = pergunta12(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 10000€")
        break
    else:
        print("Ganhou 12000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 13
    resultado = pergunta13(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 10000€")
        break
    else:
        print("Ganhou 13000€")

    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 14
    resultado = pergunta14(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 10000€")
        break
    else:
        print("Ganhou 14000€")
    cont = input("Deseja continuar o jogo? (s/n)")

    if (cont == "n" or cont == "N"):
        break

# Pergunta 15
    resultado = pergunta15(lista_niveis[index])
    if resultado == 0:
        print("Final do jogo: ganhou 10000€")
        break
    else:
        print("Parabens ganhou o prémio final de 15 Mil euros")
        break

print("Fim do jogo")
