import random


class Question:
    def __init__(self, question, options, answer):
        self.question = question
        self.options = options
        self.answer = answer


class MillionaireGame:
    def __init__(self):
        self.questions = []
        self.current_question = 0
        self.prize = 0
        self.helps = {"skip": True, "fifty_fifty": True}

    def add_question(self, question, options, answer):
        new_question = Question(question, options, answer)
        self.questions.append(new_question)

    def show_question(self):
        question = self.questions[self.current_question]
        print("Question {}: {}".format(
            self.current_question + 1, question.question))
        for i in range(len(question.options)):
            print("{}. {}".format(chr(65 + i), question.options[i]))

    def get_user_choice(self):
        user_choice = input("Enter your choice (A/B/C/D): ").upper()
        while user_choice not in ["A", "B", "C", "D"]:
            print("Invalid choice. Please choose A, B, C, or D.")
            user_choice = input("Enter your choice (A/B/C/D): ").upper()
        return user_choice

    def check_answer(self, user_choice):
        question = self.questions[self.current_question]
        if user_choice == question.answer:
            self.prize += 1000
            print("Correct!")
            return True
        else:
            print("Incorrect!")
            return False

    def use_skip(self):
        if self.helps["skip"]:
            self.current_question += 1
            self.helps["skip"] = False
            print("Skipping the question...")

    def use_fifty_fifty(self):
        if self.helps["fifty_fifty"]:
            question = self.questions[self.current_question]
            options_copy = question.options.copy()
            options_copy.remove(question.answer)
            wrong_answer = random.choice(options_copy)
            print("Incorrect answer removed: {}".format(wrong_answer))
            self.helps["fifty_fifty"] = False

    def start_game(self):
        print("Welcome to 'Who Wants to Be a Millionaire?'!")
        print("You have 2 helps: 'Skip the question' and '50/50'.")
        print("Each correct answer wins €1,000. Good luck!")
        print("=============================================")

        while self.current_question < 10:
            self.show_question()
            user_choice = self.get_user_choice()
            if user_choice == "S":
                self.use_skip()
            elif user_choice == "F":
                self.use_fifty_fifty()
            else:
                is_correct = self.check_answer(user_choice)
                if is_correct:
                    self.current_question += 1

        print("Congratulations! You answered all the questions correctly!")
        print("You won €{} in total.".format(self.prize))


if __name__ == "__main__":
    # Exemplo de uso do jogo

    # Criando as questões
    question1 = Question("What is the capital of France?", [
                         "Paris", "Madrid", "Berlin", "London"], "A")
    question2 = Question("Which planet is closest to the Sun?", [
                         "Mars", "Venus", "Mercury", "Jupiter"], "C")
    question3 = Question("What is the largest mammal?", [
                         "Elephant", "Giraffe", "Blue Whale", "Lion"], "C")
    question4 = Question("What is the chemical symbol for gold?", [
                         "Au", "Ag", "K", "P"], "A")
