import random

# Define the questions and answers
questions = [
    {
        "question": "What is the capital of France?",
        "options": ["A. London", "B. Paris", "C. Rome", "D. Madrid"],
        "answer": "B"
    },
    {
        "question": "What is the largest mammal?",
        "options": ["A. Elephant", "B. Blue whale", "C. Tiger", "D. Giraffe"],
        "answer": "B"
    },
    {
        "question": "What is the chemical symbol for gold?",
        "options": ["A. Au", "B. Ag", "C. Cu", "D. Fe"],
        "answer": "A"
    }
]

# Helper function to display the question and options


def display_question(question):
    print(question["question"])
    for option in question["options"]:
        print(option)


# Initialize game variables
correct_answers = 0
prize = 0
help_used = False

# Main game loop
for i, question in enumerate(questions, start=1):
    print("Question", i)
    display_question(question)

    # Ask for user input
    while True:
        user_choice = input(
            "Enter your choice (A/B/C/D), or type 'skip' to skip the question: ").upper()

        if user_choice == 'SKIP':
            print("Skipping the question.")
            break

        if user_choice == '50/50':
            if help_used:
                print("You have already used the 50/50 help option.")
            else:
                help_used = True
                print("Using 50/50 help option...")
                options = question["options"]
                correct_answer = question["answer"]
                options_to_remove = random.sample(
                    [option for option in options if option[0] != correct_answer], 2)
                options_to_remove.extend(
                    [option for option in options if option not in options_to_remove])
                for option in options_to_remove:
                    print(option)
        elif user_choice == question["answer"]:
            correct_answers += 1
            prize += 1000
            print("Correct!")
            break
        else:
            print("Incorrect. Please try again.")

# Display final results
print("Number of correct answers:", correct_answers)
print("Prize won (in €):", prize)
