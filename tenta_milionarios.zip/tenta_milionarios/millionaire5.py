import random

# Banco de perguntas e respostas
perguntas_respostas = {
    "Qual é a capital da França?": ["a) Paris", "b) Londres", "c) Roma", "d) Madrid", "a"],
    "Quem pintou a Mona Lisa?": ["a) Pablo Picasso", "b) Leonardo da Vinci", "c) Vincent van Gogh", "d) Salvador Dalí", "b"],
    "Qual é o maior planeta do sistema solar?": ["a) Terra", "b) Júpiter", "c) Marte", "d) Urano", "b"],
    # Adicione mais perguntas e respostas aqui
}

# Função para exibir as opções de ajuda 50/50


def ajuda_50_50(pergunta, resposta_correta):
    opcoes = perguntas_respostas[pergunta][:4]  # Obtém as primeiras 4 opções
    opcoes.remove(resposta_correta)  # Remove a resposta correta das opções
    # Escolhe aleatoriamente 2 das opções restantes
    opcoes_50_50 = random.sample(opcoes, 2)
    return opcoes_50_50

# Função para pular uma pergunta


def pular_pergunta(perguntas):
    # Escolhe aleatoriamente uma pergunta do banco de perguntas
    pergunta_pulada = random.choice(list(perguntas.keys()))
    return pergunta_pulada

# Função para executar o jogo


def jogar_quem_quer_ser_milionario():
    # Cria uma cópia do banco de perguntas para não modificar o original
    perguntas = perguntas_respostas.copy()
    acertos = 0
    pulou_pergunta = False

    print("Bem-vindo ao Quem Quer Ser Milionário!")
    print("Você tem 3 opções de ajuda: 50/50, Pular pergunta e Responder")
    print("Vamos começar:\n")

    while len(perguntas) > 0:
        # Escolhe aleatoriamente uma pergunta do banco de perguntas
        pergunta = random.choice(list(perguntas.keys()))
        print(pergunta)
        # Exibe as opções de resposta
        print(*perguntas[pergunta][:4], sep="\n")

        if not pulou_pergunta:
            print("Opções de ajuda: 50/50, Pular pergunta, Responder")
        else:
            print("Opções de ajuda: Responder")

        resposta = input(
            "Digite a letra da opção correta ou escolha uma opção de ajuda: ")

        if resposta.lower() == "50/50":
            opcoes_50_50 = ajuda_50_50(pergunta, perguntas[pergunta][4])
            print("Opções restantes após a ajuda 50/50:")
            print(*opcoes_50_50, perguntas[pergunta][4], sep="\n")
            resposta = input("Digite a letra da opção correta: ")

        if resposta.lower() == "pular pergunta":
            pergunta_pulada = pular_pergunta(perguntas)
            print("Pulando a pergunta...")
            print("Nova pergunta:
