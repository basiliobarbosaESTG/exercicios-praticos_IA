import random

# Questions and their answers
QUESTIONS = {
    "What is the capital of France?": ["A. Paris", "B. Madrid", "C. Rome", "D. Berlin", "A"],
    "What is the largest planet in our solar system?": ["A. Venus", "B. Mars", "C. Jupiter", "D. Saturn", "C"],
    "What is the currency of Japan?": ["A. Yen", "B. Won", "C. Euro", "D. Dollar", "A"],
    "What is the freezing point of water in Celsius?": ["A. 32", "B. 0", "C. -32", "D. -273", "B"],
    "What is the largest mammal?": ["A. Elephant", "B. Blue Whale", "C. Lion", "D. Giraffe", "B"],
    "Which country is known for inventing pizza?": ["A. Italy", "B. Brazil", "C. China", "D. India", "A"],
    "What is the main language spoken in Brazil?": ["A. Spanish", "B. Portuguese", "C. French", "D. English", "B"],
    "What is the chemical symbol for gold?": ["A. Go", "B. Au", "C. Ag", "D. Hg", "B"],
    "Which planet is known as the Red Planet?": ["A. Venus", "B. Mars", "C. Neptune", "D. Saturn", "B"],
    "What is the largest ocean on Earth?": ["A. Indian Ocean", "B. Atlantic Ocean", "C. Arctic Ocean", "D. Pacific Ocean", "D"]
}

# Game variables
prize = 0
num_questions = 10
questions_answered = 0
skip_used = False
fifty_fifty_used = False

# Helper function to display question and answers


def display_question(question, answers):
    print(question)
    for ans in answers:
        print(ans)


# Game loop
while questions_answered < num_questions:
    # Randomly select a question
    question = random.choice(list(QUESTIONS.keys()))

    # Display question and answers
    display_question(question, QUESTIONS[question][:4])

    # Player input
    answer = input("Enter your answer (A/B/C/D): ").upper()

    # Validate answer
    if answer in ["A", "B", "C", "D"]:
        # Check if answer is correct
        if QUESTIONS[question][4] == answer:
            prize += 1000
            questions_answered += 1
            print("Correct!")
        else:
            print("Incorrect!")
            break
    elif answer == "SKIP" and not skip_used:
        # Skip the question
        skip_used = True
        print("You have used the 'Skip the question' aid.")
    elif answer == "50/50" and not fifty_fifty_used:
        # Provide 50/50 options
        fifty_fifty_used = True
        options = list("ABCD")
        correct_answer = QUESTIONS[question][4]
        options.remove(correct_answer)
        wrong_answer = random.choice(options)
        options.remove(wrong_answer)
        remaining_options = random.sample(options, 2)
        display_question(question, [QUESTIONS[question][4], QUESTIONS[question][4].replace(correct_answer, ""), QUESTIONS[question][4].replace(wrong_answer, ""), remaining
