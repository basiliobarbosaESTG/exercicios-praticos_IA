import random

# Questions and answers
questions = [
    {
        "question": "What is the capital of France?",
        "options": ["A. Paris", "B. Rome", "C. Berlin", "D. Madrid"],
        "answer": "A"
    },
    {
        "question": "What is the largest mammal on Earth?",
        "options": ["A. Elephant", "B. Blue Whale", "C. Lion", "D. Tiger"],
        "answer": "B"
    },
    {
        "question": "What is the symbol for potassium?",
        "options": ["A. K", "B. P", "C. Fe", "D. Na"],
        "answer": "A"
    },
    {
        "question": "What is the symbol for potassium?",
        "options": ["A. K", "B. P", "C. Fe", "D. Na"],
        "answer": "A"
    },
    # Add more questions here
]

# Game state
prize = 0
current_question = 0
skip_used = False
fifty_fifty_used = False

# Helper function to display question and options


def display_question(question):
    print(question["question"])
    for option in question["options"]:
        print(option)


# Game loop
while current_question < len(questions):
    question = questions[current_question]
    display_question(question)
    answer = input("Enter your answer (A/B/C/D): ").upper()

    # Check if answer is correct
    if answer == question["answer"]:
        prize += 1000
        print("Correct!")
    else:
        print("Incorrect!")
        if skip_used:
            print("No more skips remaining.")
        if fifty_fifty_used:
            print("No more 50/50 remaining.")

    # Check if game over
    if skip_used and fifty_fifty_used:
        print("Game Over!")
        break

    # Check if player used skip aid
    if not skip_used:
        use_skip = input("Do you want to use a skip? (Y/N): ").upper()
        if use_skip == "Y":
            skip_used = True
            current_question += 1
            continue

    # Check if player used 50/50 aid
    if not fifty_fifty_used:
        use_fifty_fifty = input("Do you want to use 50/50? (Y/N): ").upper()
        if use_fifty_fifty == "Y":
            fifty_fifty_used = True
            options = question["options"]
            correct_option = question["answer"]
            incorrect_option = [
                option for option in options if option[:2] != correct_option]
            incorrect_option = random.choice(incorrect_option)
            options.remove(incorrect_option)
            print(question["question"])
            print(options[0])
            print(options[1])
            answer = input("Enter your answer (A/B/C/D): ").upper()

            # Check if answer is correct
            if answer == question["answer"]:
                prize += 1000
                print("Correct!")
            else:
                print("Incorrect!")
            current_question += 1
            continue

    # Move to next question
    current_question += 1

# Print game summary
print("Game Over!")
print("Questions answered correctly:", current_question)
print("Prize won: €" + str(prize))
