import random

PERGUNTAS = [
    {
        "pergunta": "Qual é a capital do Brasil?",
        "opcoes": ["a) São Paulo", "b) Brasília", "c) Rio de Janeiro", "d) Salvador"],
        "resposta": "b"
    },
    {
        "pergunta": "Qual é o maior planeta do Sistema Solar?",
        "opcoes": ["a) Marte", "b) Saturno", "c) Júpiter", "d) Terra"],
        "resposta": "c"
    },
    {
        "pergunta": "Quem pintou a Mona Lisa?",
        "opcoes": ["a) Pablo Picasso", "b) Claude Monet", "c) Vincent van Gogh", "d) Leonardo da Vinci"],
        "resposta": "d"
    }
]


def obter_pergunta():
    return random.choice(PERGUNTAS)


def mostrar_pergunta(pergunta):
    print(pergunta["pergunta"])
    for opcao in pergunta["opcoes"]:
        print(opcao)


def verificar_resposta(pergunta, resposta):
    return resposta.lower() == pergunta["resposta"]


def jogo_quem_quer_ser_milionario():
    print("Bem-vindo(a) ao jogo Quem Quer Ser Milionário!")
    pontos = 0
    pulos = 2
    num_questoes_acertadas = 0

    while True:
        pergunta = obter_pergunta()
        mostrar_pergunta(pergunta)
        resposta = input(
            "Digite a letra da opção correta (ou digite '50/50' para pedir ajuda ou 'pular' para pular a pergunta): ")

        if resposta == "50/50":
            if pulos > 0:
                opcoes = pergunta["opcoes"]
                opcoes_corretas = [pergunta["resposta"]]
                opcoes_erradas = list(set(opcoes) - set(opcoes_corretas))
                opcoes_50_50 = random.sample(opcoes_erradas, 2)
                opcoes_50_50.append(pergunta["resposta"])
                random.shuffle(opcoes_50_50)
                print("Opções restantes: ")
                for opcao in opcoes_50_50:
                    print(opcao)
                pulos -= 1
                continue
            else:
                print("Você não possui mais pulos disponíveis.")
                continue

        if resposta == "pular":
            if pulos > 0:
                print("Pulando para a próxima pergunta...")
                pulos -= 1
                continue
            else:
                print("Você não possui mais pulos disponíveis.")
                continue

        if verificar_resposta(pergunta, resposta):
            print("Resposta correta!")
            pontos += 1000
            num_questoes_acertadas += 1
        else:
            print("Resposta incorreta!")
            break

    premio = num_questoes_acertadas * 1000
    print("Fim de jogo! Você acertou {} questões e ganhou {}€.".format(
        num_questoes_acertadas, premio))


# Iniciar o jogo
jogo_quem_quer_ser_milionario()
