import random

# Lista de perguntas e respostas
perguntas = [
    {
        "pergunta": "Qual é a capital de Portugal?",
        "opcoes": ["Lisboa", "Madrid", "Roma", "Paris"],
        "resposta": "Lisboa"
    },
    {
        "pergunta": "Qual é a montanha mais alta do mundo?",
        "opcoes": ["Everest", "Kilimanjaro", "Aconcágua", "Monte Branco"],
        "resposta": "Everest"
    },
    {
        "pergunta": "Qual é a moeda oficial do Brasil?",
        "opcoes": ["Dólar", "Real", "Peso", "Euro"],
        "resposta": "Real"
    },
    # Adicione mais perguntas aqui
]

# Função para embaralhar as opções de resposta


def embaralhar_opcoes(opcoes):
    random.shuffle(opcoes)
    return opcoes

# Função para imprimir as opções de resposta


def imprimir_opcoes(opcoes):
    for i, opcao in enumerate(opcoes):
        print(f"{i+1}) {opcao}")
    print()

# Função para apresentar uma pergunta e receber a resposta do jogador


def fazer_pergunta(pergunta):
    print(pergunta["pergunta"])
    opcoes = embaralhar_opcoes(pergunta["opcoes"])
    imprimir_opcoes(opcoes)
    resposta = input("Escolha a resposta correta (1 a 4): ")
    while resposta not in ["1", "2", "3", "4"]:
        print("Opção inválida. Por favor, escolha novamente.")
        resposta = input("Escolha a resposta correta (1 a 4): ")
    resposta = int(resposta)
    if opcoes[resposta-1] == pergunta["resposta"]:
        print("Resposta correta!")
        return True
    else:
        print("Resposta incorreta.")
        return False

# Função para usar a ajuda "50/50"


def usar_ajuda_50_50(pergunta):
    opcoes = embaralhar_opcoes(pergunta["opcoes"])
    opcoes_restantes = [
        opcao for opcao in opcoes if opcao != pergunta["resposta"]]
    opcoes_restantes = random.sample(opcoes_restantes, 2)
    opcoes_restantes.append(pergunta["resposta"])
    opcoes_restantes = embaralhar_opcoes(opcoes_restantes)
    print("Opções restantes:")
    imprimir_opcoes(opcoes_restantes)

# Função para usar a ajuda "Saltar a pergunta"


def usar_ajuda_saltar(pergunta):
    print("Pergunta pulada.")

# Função para imprimir o resultado final


def imprimir_resultado(corretas, premio):
    print(f"Perguntas respondidas corretamente: {corretas}")
    print(f"Prêmio ganho: {premio}€")

# Função principal do jogo


def jogar_quem_quer_ser_milionario():
    print("Bem-vindo ao Quem Quer Ser Milionário!")
    corretas = 0
    premio = 0
    for i, pergunta in enumerate(perguntas):
        print(f"Pergunta {i+1}:")
        print("------------------------------")
        print
