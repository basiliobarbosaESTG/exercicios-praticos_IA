import random

# List of questions with answers and options
questions = [
    {
        "question": "What is the capital of France?",
        "options": ["A. Paris", "B. London", "C. Berlin", "D. Rome"],
        "answer": "A"
    },
    {
        "question": "What is the largest planet in our solar system?",
        "options": ["A. Venus", "B. Mars", "C. Jupiter", "D. Saturn"],
        "answer": "C"
    },
    {
        "question": "What is the symbol for gold in the periodic table?",
        "options": ["A. G", "B. Au", "C. Ag", "D. Cu"],
        "answer": "B"
    },
    # Add more questions here
]

# Initial prize money
prize = 0

# Number of questions answered correctly
correct_answers = 0

# Helper function to print question and options


def print_question(question):
    print(question["question"])
    for option in question["options"]:
        print(option)


# Main game loop
for i in range(len(questions)):
    print("Question", i + 1, ":")
    print_question(questions[i])

    # Player's choice
    choice = input("Enter your choice (A/B/C/D): ").upper()

    # Check if the choice is correct
    if choice == questions[i]["answer"]:
        print("Correct!")
        correct_answers += 1
        prize += 1000
    else:
        print("Incorrect!")

    # Check if the player has won the game
    if correct_answers == len(questions):
        print("Congratulations! You answered all the questions correctly.")
        print("You won €" + str(prize) + "!")
        break

    # Player's aids
    if i < len(questions) - 1:
        aid_choice = input("Do you want to use an aid? (Y/N): ").upper()
        if aid_choice == "Y":
            aids = ["Skip the question", "50/50"]
            aid = random.choice(aids)
            print("You chose to use:", aid)
            if aid == "Skip the question":
                print("Skipping to the next question...")
            elif aid == "50/50":
                correct_option = questions[i]["answer"]
                wrong_options = [option for option in questions[i]
                                 ["options"] if option[0] != correct_option]
                wrong_option = random.choice(wrong_options)
                print("The 50/50 options are:")
                print(correct_option)
                print(wrong_option)
                choice = input("Enter your choice (A/B/C/D): ").upper()

# Print number of questions answered correctly and prize money won
print("Number of questions answered correctly:", correct_answers)
print("Prize money won: €" + str(prize))
