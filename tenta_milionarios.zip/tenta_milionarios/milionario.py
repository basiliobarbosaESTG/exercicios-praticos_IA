import random

# Questions with answers and options
questions = [
    {
        "question": "What is the capital of France?",
        "options": ["A. Paris", "B. London", "C. Berlin", "D. Rome"],
        "answer": "A"
    },
    {
        "question": "What is the largest planet in our solar system?",
        "options": ["A. Mars", "B. Jupiter", "C. Saturn", "D. Venus"],
        "answer": "B"
    },
    {
        "question": "What is the color of an emerald?",
        "options": ["A. Blue", "B. Red", "C. Green", "D. Yellow"],
        "answer": "C"
    },
    # Add more questions here
]

# Function to display the question and options


def display_question(question):
    print(question["question"])
    for option in question["options"]:
        print(option)

# Function to get user's choice


def get_choice():
    choice = input("Enter your choice (A/B/C/D): ").upper()
    while choice not in ["A", "B", "C", "D"]:
        print("Invalid choice. Please choose from A, B, C, or D.")
        choice = input("Enter your choice (A/B/C/D): ").upper()
    return choice


# Shuffle the questions
random.shuffle(questions)

# Initialize game variables
num_correct_answers = 0
prize = 0
num_questions = len(questions)
used_jump_question = False
used_fifty_fifty = False

# Main game loop
for i, question in enumerate(questions):
    display_question(question)
    choice = get_choice()

    # Check if choice is correct
    if choice == question["answer"]:
        print("Correct!")
        num_correct_answers += 1
        prize += 1000

    else:
        print("Incorrect.")

        # Check if player has used jump question aid
        if not used_jump_question:
            use_jump_question = input(
                "Do you want to use 'Jump the question' aid? (Y/N): ").upper()
            if use_jump_question == "Y":
                used_jump_question = True
                continue

        # Check if player has used 50/50 aid
        if not used_fifty_fifty:
            use_fifty_fifty = input(
                "Do you want to use '50/50' aid? (Y/N): ").upper()
            if use_fifty_fifty == "Y":
                used_fifty_fifty = True
                options = question["options"]
                options.remove(question["answer"])
                random.shuffle(options)
                options = options[:2]
                options.append(question["answer"])
                random.shuffle(options)
                print("Options: ")
                for option in options:
                    print(option)
                choice = get_choice()
                if choice == question["answer"]:
                    print("Correct!")
                    num_correct_answers += 1
                    prize += 1000
                else:
                    print("Incorrect.")

    print("---------------")

# Print game results
print("Game Over!")
print("Number of questions answered correctly: ", num_correct_answers)
print("Prize amount won: €", prize)
