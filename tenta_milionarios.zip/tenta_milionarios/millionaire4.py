import random

# Lista de perguntas com suas respectivas respostas e opções
perguntas = [
    {
        "pergunta": "Qual é a capital da França?",
        "opcoes": ["a) Roma", "b) Paris", "c) Madrid", "d) Berlim"],
        "resposta": "b"
    },
    {
        "pergunta": "Qual é a cor do céu em um dia ensolarado?",
        "opcoes": ["a) Verde", "b) Azul", "c) Amarelo", "d) Vermelho"],
        "resposta": "b"
    },
    {
        "pergunta": "Qual é o maior animal terrestre?",
        "opcoes": ["a) Elefante", "b) Girafa", "c) Rinoceronte", "d) Leão"],
        "resposta": "a"
    },
    # Adicione mais perguntas aqui
]


def jogar_quem_quer_ser_um_milionario():
    print("Bem-vindo ao Quem Quer Ser um Milionário!")
    print("Você tem a chance de ganhar até € 10.000!")
    print("Você pode usar duas ajudas durante o jogo: 'Skip the question' e '50/50'.")
    print("Vamos começar!\n")

    pontos = 0  # Pontuação do jogador
    ajuda_skip = True  # Ajuda "Skip the question" disponível
    ajuda_5050 = True  # Ajuda "50/50" disponível

    # Loop através das perguntas
    for i, pergunta in enumerate(perguntas, 1):
        print(f"Pergunta {i}: {pergunta['pergunta']}")
        for opcao in pergunta['opcoes']:
            print(opcao)
        resposta = input("Escolha a resposta correta (a, b, c ou d): ").lower()

        # Verificar resposta
        if resposta == pergunta['resposta']:
            pontos += 1000
            print("Resposta correta!")
        else:
            print("Resposta incorreta!")
            print(f"Você ganhou € {pontos}.")
            break

        # Verificar se jogador ganhou o jogo
        if pontos == 10000:
            print("Parabéns! Você ganhou € 10.000!")
            break

        # Verificar se o jogador deseja usar a ajuda "Skip the question"
        if ajuda_skip:
            usar_ajuda_skip = input(
                "Deseja usar a ajuda 'Skip the question'? (s/n): ").lower()
            if usar_ajuda_skip == 's':
                ajuda_skip = False
                continue

        # Verificar se o jogador deseja usar a ajuda "50/50"
        if ajuda_5050:
            usar_ajuda_5050 = input(
                "Deseja usar a ajuda '50/50'? (s/n): ").lower()
            if usar_ajuda_5050 == 's':
                ajuda_5050 = False
                # Excluir duas opções incorretas aleatoriamente
                opcoes = pergunta['opcoes']
                opcoes.remove(pergunta['resposta'])
                opcoes_incorretas = random.sample(opcoes, 2)
                for opcao in pergunta['opcoes']:
                    if opcao not in op
