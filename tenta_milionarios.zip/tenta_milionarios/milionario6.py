import random

# List of questions and their corresponding answers
questions = [
    {
        "question": "What is the capital of France?",
        "options": ["A. Paris", "B. Rome", "C. Madrid", "D. Berlin"],
        "answer": "A"
    },
    {
        "question": "What is the largest mammal?",
        "options": ["A. Elephant", "B. Whale", "C. Rhino", "D. Lion"],
        "answer": "B"
    },
    {
        "question": "What is the currency of Japan?",
        "options": ["A. Yen", "B. Dollar", "C. Euro", "D. Pound"],
        "answer": "A"
    },
    {
        "question": "What is the tallest mountain in the world?",
        "options": ["A. Mount Kilimanjaro", "B. Mount Everest", "C. Mount Fuji", "D. Mount McKinley"],
        "answer": "B"
    },
    {
        "question": "What was Walt Disney's middle name?",
        "options": ["A. James", "B. Elias", "C. Winston", "D. Benjamin"],
        "answer": "B"
    },
    {
        "question": "What year did Martin Luther King Jr. won the Nobel Peace Prize?",
        "options": ["A. 1957", "B. 1963", "C. 1964", "D. 1968"],
        "answer": "C"
    },
    {
        "question": "Singer Elton John was president of which English football club?",
        "options": ["A. Watford", "B. Aston Villa", "C. Everton", "D. Newcastle"],
        "answer": "A"
    },
    {
        "question": "Before becoming the queen of pop, singer Madonna was part of which of these bands?",
        "options": ["A. Culture Club", "B. Tom Tom Club", "C. The Gun Club", "D. Breakfast Club"],
        "answer": "D"
    },
    {
        "question": "Queen Anne was the daughter of which English Monarch?",
        "options": ["A. James II", "B. Henry VII", "C. Victoria", "D. William I"],
        "answer": "A"
    },
    {
        "question": "Who composed 'Rhapsody in Blue'?",
        "options": ["A. Irving Berlin", "B. Aaron Copland", "C. Cole Porter", "D. George Gershwin"],
        "answer": "D"
    }
]

# Function to display the question and options


def display_question(question):
    print(question["question"])
    for option in question["options"]:
        print(option)

# Function to display the available help options


def display_help_options():
    print("Help options:")
    print("1. 50/50 - Eliminate two incorrect options")
    print("2. Skip - Skip the current question")

# Function to implement 50/50 help option


def fifty_fifty(question):
    options = question["options"]
    correct_answer = question["answer"]
    # options.remove(correct_answer) # da erro
    incorrect_answer = random.choice(options)
    options.remove(incorrect_answer)
    options.append(correct_answer)
    return options

# Function to start the game


def play_game():
    correct_answers = 0
    prize = 0
    help_used = False

    # Shuffle the questions
    random.shuffle(questions)

    for question in questions:
        display_question(question)
        display_help_options()
        answer = input(
            "Enter your answer (A/B/C/D), or type 'help' for help options, or type 'skip' to skip the question: ").upper()

        # Check for help options
        if answer == "HELP":
            if not help_used:
                help_option = input("Enter your choice for help (1/2): ")
                if help_option == "1":
                    options = fifty_fifty(question)
                    print("Remaining options after using 50/50 help:")
                    for option in options:
                        print(option)
                    help_used = True
                    continue
                elif help_option == "2":
                    print("Skipped the current question.")
                    continue
                else:
                    print("Invalid choice. Please try again.")
                    continue
            else:
                print("You have already used all the available help options.")
                continue

        # Check for skipping the question
        if answer == "SKIP":
            print("Skipped the current question.")
            continue

        # Check for correct answer
        if answer == question["answer"]:
            correct_answers += 1
            prize += 1000
            print("Correct!")
        else:
            print("Incorrect. The correct answer is", question["answer"])

    print("Number of correct answers:", correct_answers)
    print("Total prize won: €", prize)


# Start the game
play_game()
