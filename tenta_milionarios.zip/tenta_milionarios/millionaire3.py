import random

# Lista de perguntas com suas respectivas respostas e opções
perguntas = [
    {
        "pergunta": "Qual é a capital da França?",
        "opcoes": ["a) Roma", "b) Paris", "c) Madrid", "d) Berlim"],
        "resposta": "b"
    },
    {
        "pergunta": "Qual é a cor do céu em um dia ensolarado?",
        "opcoes": ["a) Verde", "b) Azul", "c) Amarelo", "d) Vermelho"],
        "resposta": "b"
    },
    {
        "pergunta": "Qual é o maior animal terrestre?",
        "opcoes": ["a) Elefante", "b) Girafa", "c) Rinoceronte", "d) Leão"],
        "resposta": "a"
    },
    # Mais perguntas aqui...
]


def jogar_quem_quer_ser_um_milionario():
    print("Bem-vindo ao Quem Quer Ser um Milionário!")
    print("Você tem a chance de ganhar até € 10.000!")
    print("Você pode usar duas ajudas durante o jogo: 'Skip the question' e '50/50'.")
    print("Vamos começar!\n")

    pontos = 0  # Pontuação do jogador
    ajuda_skip = True  # Ajuda "Skip the question" disponível

    # Loop para cada pergunta
    for i in range(len(perguntas)):
        print(f"Pergunta {i + 1}:")
        print(perguntas[i]["pergunta"])
        for opcao in perguntas[i]["opcoes"]:
            print(opcao)
        resposta = input(
            "Digite a letra da opção correta (a, b, c ou d): ").lower()

        # Verifica se a resposta está correta
        if resposta == perguntas[i]["resposta"]:
            print("Resposta correta!")
            pontos += 1000
        else:
            print("Resposta incorreta!")
            # Verifica se a ajuda "Skip the question" está disponível
            if ajuda_skip:
                usar_skip = input(
                    "Deseja usar a ajuda 'Skip the question'? (s/n): ").lower()
                if usar_skip == "s":
                    ajuda_skip = False  # Desativa a ajuda "Skip the question"
                    continue  # Pula para a próxima pergunta
            # Verifica se a ajuda "50/50" está disponível
            if i < len(perguntas) - 1:
                usar_50_50 = input(
                    "Deseja usar a ajuda '50/50'? (s/n): ").lower()
                if usar_50_50 == "s":
                    # Exibe a pergunta com apenas duas opções, sendo uma correta e outra incorreta
                    opcoes = perguntas[i]["opcoes"]
                    opcoes_corretas = [opcao for opcao in opcoes if opcao.startswith(
                        perguntas[i]["resposta"])]
                    opcao_incorreta = random.choice(
                        [opcao for opcao in opcoes if opcao not in opcoes_corretas])
                    print(f"Opções: {opcoes_corretas[0]} ou {opcao_incorreta}")
                    resposta_50_50 = input("Digite a letra da opção correta(a
