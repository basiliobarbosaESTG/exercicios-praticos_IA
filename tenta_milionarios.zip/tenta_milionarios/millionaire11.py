import random


class QuemQuerSerMilionario:
    def __init__(self):
        self.perguntas = [
            {
                "pergunta": "Qual é a capital da França?",
                "opcoes": ["a) Londres", "b) Paris", "c) Berlim", "d) Roma"],
                "resposta": "b"
            },
            {
                "pergunta": "Qual é o maior planeta do Sistema Solar?",
                "opcoes": ["a) Vênus", "b) Júpiter", "c) Marte", "d) Saturno"],
                "resposta": "b"
            },
            {
                "pergunta": "Qual é o maior mamífero terrestre?",
                "opcoes": ["a) Elefante", "b) Leão", "c) Baleia Azul", "d) Girafa"],
                "resposta": "a"
            },
            {
                "pergunta": "Qual é a ciência que estuda os pés num sentido de saúde?",
                "opcoes": ["a) Posologia", "b) Podologia", "c) Pesologia", "d) Podontologia"],
                "resposta": "b"
            },
            {
                "pergunta": "A atriz e estrela de cinema Natalie Portman nasceu em qual país?",
                "opcoes": ["a) EUA", "b) Grécia", "c) Canadá", "d) Israel"],
                "resposta": "d"
            },
            {
                "pergunta": "Qual era o nome do meio de Walt Disney?",
                "opcoes": ["a) James", "b) Elias", "c) Winston", "d) Benjamin"],
                "resposta": "b"
            },
            {
                "pergunta": "Em que ano aconteceu a primeira cerimônia de entrega do Oscar?",
                "opcoes": ["a) 1925", "b) 1929", "c) 1933", "d) 1938"],
                "resposta": "b"
            },
            {
                "pergunta": "Em que ano Martin Luther King Jr. ganhou o prêmio Nobel da Paz?",
                "opcoes": ["a) 1957", "b) 1963", "c) 1964", "d) 1968"],
                "resposta": "c"
            },
            {
                "pergunta": "O cantor Elton John foi presidente de que clube inglês de futebol?",
                "opcoes": ["a) Watford", "b) Aston Villa", "c) Everton", "d) Newcastle"],
                "resposta": "a"
            },
            {
                "pergunta": "Antes de se tornar a rainha do pop, a cantora Madonna integrou qual destas bandas?",
                "opcoes": ["a) Culture Club", "b) Tom Tom Club", "c) The Gun Club", "d) Breakfast Club"],
                "resposta": "d"
            }
            # Adicione mais perguntas aqui
        ]
        self.pontuacao = 0
        self.ajuda_50_50_usada = False
        self.pular_pergunta_usado = False

    def mostrar_pergunta(self, pergunta):
        print(pergunta["pergunta"])
        for opcao in pergunta["opcoes"]:
            print(opcao)
        print()

    def usar_ajuda_50_50(self, pergunta):
        opcoes_corretas = [pergunta["resposta"]]
        opcoes_incorretas = list(
            set(pergunta["opcoes"]) - set(opcoes_corretas))
        opcoes_incorretas.remove(random.choice(opcoes_incorretas))
        print("Opções corretas: ", opcoes_corretas)
        print("Opções incorretas: ", opcoes_incorretas)
        self.ajuda_50_50_usada = True

    def pular_pergunta(self):
        self.pular_pergunta_usado = True

    def jogar(self):
        random.shuffle(self.perguntas)
        for pergunta in self.perguntas:
            self.mostrar_pergunta(pergunta)
            resposta = input(
                "Digite a letra da resposta correta (ou 'ajuda' para usar a ajuda 50/50, ou 'pular' para pular a pergunta): ")
            resposta = resposta.lower()
            if resposta == "ajuda":
                if not self.ajuda_50_50_usada:
                    self.usar_ajuda_50_50(pergunta)
                else:
                    print("Você já usou a ajuda 50/50.")
                    continue
            elif resposta == "pular":
                if not self.pular_pergunta_usado:
                    self.pular_pergunta()
                else:
                    print("Você já pulou uma pergunta.")
                    continue
            else:
                if resposta == pergunta["resposta"]:
                    print("Resposta correta!")
                    self.pontuacao += 1000
                else:
                    print("Resposta incorreta!")
                    break
        print("Fim de jogo!")
        print("Sua pontuação: ", self.pontuacao)


jogo = QuemQuerSerMilionario()
jogo.jogar()
